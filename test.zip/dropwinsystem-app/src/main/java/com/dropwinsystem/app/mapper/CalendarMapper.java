package com.dropwinsystem.app.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.dropwinsystem.app.domain.Calendar;

@Mapper
public interface CalendarMapper {
	/**
     * 캘린더 일정 조회하기
     * @return
     * @throws Exception
     */
    List<Calendar> calendarList() throws Exception;

    /**
     * 캘린더 일정 저장하기
     * @param vo
     * @throws Exception
     */
    void calendarSave(Calendar calendar) throws Exception;

    /**
     * 캘린더 일정 삭제하기
     * @param no
     * @throws Exception
     */
    void calendarDelete(String no) throws Exception;

    /**
     * 캘린더 일정 수정하기
     * @param vo
     * @throws Exception
     */
    void eventUpdate(Calendar calendar) throws Exception;
}

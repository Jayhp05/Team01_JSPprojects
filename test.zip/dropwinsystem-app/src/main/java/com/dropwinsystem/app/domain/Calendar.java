package com.dropwinsystem.app.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Calendar {
	private Long calendarNo;
    private String title;
    private String start1;
    private String end;
    private boolean allDay;
}

package com.dropwinsystem.app.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dropwinsystem.app.domain.Notice;
import com.dropwinsystem.app.mapper.NoticeMapper;

@Service
public class NoticeServiceImpl implements NoticeService {

	@Autowired
	private NoticeMapper noticeMapper;

	private static final int PAGE_SIZE = 10;

	private static final int PAGE_GROUP = 10;

	@Override
	public Map<String, Object> getNoticeList(int pageNum, String type, String keyword) {

		int currentPage = pageNum;

		int startRow = (currentPage - 1) * PAGE_SIZE;

		boolean searchOption = (type.equals("null") || keyword.equals("null")) ? false : true;

		int listCount = noticeMapper.getNoticeCount(type, keyword);

		List<Notice> noticeList = noticeMapper.noticeList(startRow, PAGE_SIZE, type, keyword);

		int pageCount = listCount / PAGE_SIZE + (listCount % PAGE_SIZE == 0 ? 0 : 1);

		int startPage = (currentPage / PAGE_GROUP) * PAGE_GROUP + 1 - (currentPage % PAGE_GROUP == 0 ? PAGE_GROUP : 0);

		int endPage = startPage + PAGE_GROUP - 1;

		if (endPage > pageCount) {
			endPage = pageCount;
		}

		Map<String, Object> result = new HashMap<>();
		result.put("nList", noticeList);
		result.put("pageCount", pageCount);
		result.put("startPage", startPage);
		result.put("endPage", endPage);
		result.put("currentPage", currentPage);
		result.put("listCount", listCount);
		result.put("pageGroup", PAGE_GROUP);
		result.put("searchOption", searchOption);

		return result;
	}
	
	public Notice getNotice(int no, boolean isCount) {	
		if(isCount) {
			noticeMapper.increaseViewCount(no);
		}
		return noticeMapper.getNotice(no);
	}
	
	public void addNotice(Notice notice) {
		noticeMapper.insertNotice(notice);
	}

	public boolean isPassCheck(int no, String pass) {	
		boolean result = false;
		
		// BoardMapper를 이용해 DB에서 no에 해당하는 비밀번호를 읽어온다.
		String dbPass = noticeMapper.isPassCheck(no);
		
		if(dbPass.equals(pass)) {
			result = true;		
		}
		
		// 비밀번호가 맞으면 true, 맞지 않으면 false가 반환된다.
		return result;
	}	

	// 게시글을 수정하는 메서드
	public void updateNotice(Notice notice) {
		noticeMapper.updateNotice(notice);
	}
	
	public void deleteNotice(int no) {
		noticeMapper.deleteNotice(no);
	}
	
	public Map<String, Integer> likeCount(int no, String likeCount) {
		
		noticeMapper.updateLikeCount(no, likeCount);
		Notice notice = noticeMapper.getLikeCount(no);
		
		Map<String, Integer> map = new HashMap<String, Integer>(); 
		map.put("recommend", notice.getLikeCount());
		map.put("decommendation", notice.getLikeCount());
		return map;
	}
	
}
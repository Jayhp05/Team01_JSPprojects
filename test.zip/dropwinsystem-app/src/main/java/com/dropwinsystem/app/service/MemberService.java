package com.dropwinsystem.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.dropwinsystem.app.domain.Member;
import com.dropwinsystem.app.mapper.MemberMapper;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MemberService {

	@Autowired
	private MemberMapper memberMapper;

	@Autowired
	private PasswordEncoder passwordEncoder;

	public int login(String id, String pass) {
		int result = -1;
		Member m = memberMapper.getMember(id);

		if(m == null) {
			return result;
		}
	
		if(passwordEncoder.matches(pass, m.getPass())) {
			result = 1;
			
		} else { // 비밀번호가 틀리면 : 0
			result = 0;
		}
		
		return result;
	}
	
	// 회원 ID에 해당하는 회원 정보를 읽어와 반환하는 메서드	
	public Member getMember(String id) {
		return memberMapper.getMember(id);
	}
	
	// 회원 가입시 아이디 중복을 체크하는 메서드	
	public boolean overlapIdCheck(String id) {
		Member member = memberMapper.getMember(id);
		log.info("overlapIdCheck - member : " + member);
		if(member == null) {
			return false;
		}
		return true;
	}

	public void addMember(Member member) {

		member.setPass(passwordEncoder.encode(member.getPass()));
		
		/* 아래는 문자열 "1234"를 BCryptPasswordEncoder 객체를 사용해
		 * 암호화한 것으로 동일한 문자열을 암호화 하더라도 그 결과는 모두 다를 수 있다. 
		 **/ 
		// $2a$10$aWYm2BGI/0iMuemBeF4Y8.7WZeVKAoudv/VzgQx697lYlZgQxr/pe
		// $2a$10$b3t8sn6QZGHYaRx3OS5KUuPxzWZdY5yHPRxlSdAgByQ7v0BlCLzrO
		// $2a$10$.g6l.wyIFO1.j4u4gvVtKOnG9ACBUT1GRlDwlMZcjBxZPrCAURLaG
		// $2a$10$l37iiJWozST9.2EI11vjqOmSk9rus.5cawhTiPuQagCzVNTZcoFDa
		// $2a$10$qtxKvIgk.URhyqgx93KYFuw4e8Rh3IhIkR0CTZhd.HazLal7d3rqK
		log.info(member.getPass());
		memberMapper.addMember(member);
	}

	public boolean memberPassCheck(String id, String pass) {		
		
		String dbPass = memberMapper.memberPassCheck(id);		
		boolean result = false;		
	
		if(passwordEncoder.matches(pass, dbPass)) {
			result = true;	
		}
		return result;	
	}

	public void updateMember(Member member) {

		member.setPass(passwordEncoder.encode(member.getPass()));
		log.info(member.getPass());
		
		memberMapper.updateMember(member);
	}	
}

package com.dropwinsystem.app.ajax;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dropwinsystem.app.service.NoticeService;

@RestController
public class NoticeAjaxController {
	
	// 의존객체 주입 설정
	@Autowired
	private NoticeService noticeService;

	@PostMapping("/likeCount.ajax")
	public Map<String, Integer> likeCount(@RequestParam("no") int no,
			@RequestParam("likeCount") String likeCount) {
	
		return noticeService.likeCount(no, likeCount);		
	}

}

package com.dropwinsystem.app.service;

import java.util.Map;

import com.dropwinsystem.app.domain.Notice;

public interface NoticeService {
	
	Map<String, Object> getNoticeList(int pageNum, String type, String keyword);

    Notice getNotice(int no, boolean isCount);

    void addNotice(Notice notice);

    boolean isPassCheck(int no, String pass);

    void updateNotice(Notice notice);

    void deleteNotice(int no);

    Map<String, Integer> likeCount(int no, String likeCount);
}

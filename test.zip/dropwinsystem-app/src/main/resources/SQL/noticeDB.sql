CREATE DATABASE IF NOT EXISTS dropwin;
use dropwin;

-- 공지사항 DB

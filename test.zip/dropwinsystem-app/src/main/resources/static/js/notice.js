// notice.js
$.ajax({
    url: "/api/notices",
    method: "GET",
    success: function(data) {
        console.log("목록:", data);
    },
    error: function(xhr) {
        console.error("목록 조회 실패", xhr);
    }
});

// 상세보기 호출
$.ajax({
    url: "/api/notices/1",
    method: "GET",
    success: function(data) {
        console.log("상세:", data);
    },
    error: function(xhr) {
        console.error("상세 조회 실패", xhr);
    }
});

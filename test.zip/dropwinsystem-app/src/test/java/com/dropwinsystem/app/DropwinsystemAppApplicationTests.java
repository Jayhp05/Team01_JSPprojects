package com.dropwinsystem.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DropwinsystemAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
